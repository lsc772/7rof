const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.static(path.join(__dirname, 'public')));

// حالة اللعبة
let gameState = {
  board: {},
  letters: shuffleLetters(),
  scores: { orange: 0, cyan: 0 },
  buzzerActive: false,
  buzzerWinner: null,
  frozenTeam: null,
  frozenUntil: null,
  players: { team1: [], team2: [] },
  hostConnected: false
};

const allLetters = ['ز','ت','س','ذ','ث','م','و','ل','أ','ص','ق','غ','ع','د','ن','ط','و','خ','ك','ر','ض','ج','ي','ب','ح'];

function shuffleLetters() {
  const a = [...allLetters];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const clients = new Map(); // ws -> { role, name, team }

function broadcast(data, excludeWs = null) {
  const msg = JSON.stringify(data);
  wss.clients.forEach(ws => {
    if (ws !== excludeWs && ws.readyState === WebSocket.OPEN) {
      ws.send(msg);
    }
  });
}

function broadcastAll(data) {
  const msg = JSON.stringify(data);
  wss.clients.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) ws.send(msg);
  });
}

function sendState(ws) {
  ws.send(JSON.stringify({ type: 'state', state: gameState }));
}

function broadcastState() {
  broadcastAll({ type: 'state', state: gameState });
}

function checkPath(color) {
  const rows = 5, cols = 5;
  const board = gameState.board;
  const visited = new Set();
  const queue = [];

  if (color === 'orange') {
    for (let c = 0; c < cols; c++) {
      const key = `0,${c}`;
      if (board[key] === 'orange') { queue.push([0, c]); visited.add(key); }
    }
    while (queue.length) {
      const [r, c] = queue.shift();
      if (r === rows - 1) return true;
      for (const [nr, nc] of getNeighbors(r, c, rows, cols)) {
        const nk = `${nr},${nc}`;
        if (!visited.has(nk) && board[nk] === 'orange') { visited.add(nk); queue.push([nr, nc]); }
      }
    }
  } else {
    for (let r = 0; r < rows; r++) {
      const key = `${r},0`;
      if (board[key] === 'cyan') { queue.push([r, 0]); visited.add(key); }
    }
    while (queue.length) {
      const [r, c] = queue.shift();
      if (c === cols - 1) return true;
      for (const [nr, nc] of getNeighbors(r, c, rows, cols)) {
        const nk = `${nr},${nc}`;
        if (!visited.has(nk) && board[nk] === 'cyan') { visited.add(nk); queue.push([nr, nc]); }
      }
    }
  }
  return false;
}

function getNeighbors(row, col, rows, cols) {
  const dirs = row % 2 === 0
    ? [[-1,-1],[-1,0],[0,-1],[0,1],[1,-1],[1,0]]
    : [[-1,0],[-1,1],[0,-1],[0,1],[1,0],[1,1]];
  return dirs.map(([dr,dc]) => [row+dr, col+dc])
    .filter(([r,c]) => r>=0 && r<rows && c>=0 && c<cols);
}

wss.on('connection', (ws) => {
  clients.set(ws, { role: null, name: null, team: null });

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }
    const client = clients.get(ws);

    switch (msg.type) {

      case 'join': {
        client.role = msg.role; // 'team1' | 'team2' | 'host'
        client.name = msg.name;
        client.team = msg.role === 'team1' ? 'orange' : msg.role === 'team2' ? 'cyan' : null;

        if (msg.role === 'host') {
          gameState.hostConnected = true;
        } else {
          if (!gameState.players[msg.role]) gameState.players[msg.role] = [];
          if (!gameState.players[msg.role].includes(msg.name)) {
            gameState.players[msg.role].push(msg.name);
          }
        }
        sendState(ws);
        broadcastState();
        break;
      }

      case 'click_cell': {
        if (client.role === 'host') break;
        const team = client.team;
        // تحقق من التجميد
        if (gameState.frozenTeam === team && Date.now() < gameState.frozenUntil) break;
        const key = msg.key;
        const cur = gameState.board[key] || 'white';
        gameState.board[key] = cur === 'white' ? team : cur === team ? 'white' : team;

        // تحقق من الفوز
        if (checkPath(team)) {
          gameState.scores[team]++;
          // امسح خلايا الفريق
          for (const k of Object.keys(gameState.board)) {
            if (gameState.board[k] === team) delete gameState.board[k];
          }
          broadcastAll({ type: 'win', team, scores: gameState.scores });
        }
        broadcastState();
        break;
      }

      case 'buzzer': {
        if (client.role === 'host') break;
        const team = client.team;
        // تحقق تجميد
        if (gameState.frozenTeam === team && Date.now() < gameState.frozenUntil) break;
        if (!gameState.buzzerActive) {
          gameState.buzzerActive = true;
          gameState.buzzerWinner = { name: client.name, team };
          broadcastAll({ type: 'buzzer_hit', name: client.name, team });
          broadcastState();
        }
        break;
      }

      case 'reset_buzzer': {
        if (client.role !== 'host') break;
        gameState.buzzerActive = false;
        gameState.buzzerWinner = null;
        broadcastState();
        break;
      }

      case 'freeze_team': {
        if (client.role !== 'host') break;
        const { team } = msg;
        gameState.frozenTeam = team;
        gameState.frozenUntil = Date.now() + 10000;
        gameState.buzzerActive = false;
        gameState.buzzerWinner = null;
        broadcastAll({ type: 'frozen', team, until: gameState.frozenUntil });
        broadcastState();
        // ارفع التجميد تلقائياً بعد 10 ثواني
        setTimeout(() => {
          if (gameState.frozenTeam === team) {
            gameState.frozenTeam = null;
            gameState.frozenUntil = null;
            broadcastAll({ type: 'unfrozen', team });
            broadcastState();
          }
        }, 10000);
        break;
      }

      case 'award_point': {
        if (client.role !== 'host') break;
        const { team } = msg;
        gameState.scores[team]++;
        gameState.buzzerActive = false;
        gameState.buzzerWinner = null;
        broadcastAll({ type: 'point_awarded', team, scores: gameState.scores });
        broadcastState();
        break;
      }

      case 'reset_board': {
        if (client.role !== 'host') break;
        gameState.board = {};
        gameState.letters = shuffleLetters();
        gameState.buzzerActive = false;
        gameState.buzzerWinner = null;
        gameState.frozenTeam = null;
        gameState.frozenUntil = null;
        broadcastState();
        break;
      }

      case 'reset_scores': {
        if (client.role !== 'host') break;
        gameState.scores = { orange: 0, cyan: 0 };
        broadcastState();
        break;
      }
    }
  });

  ws.on('close', () => {
    const client = clients.get(ws);
    if (client) {
      if (client.role && client.role !== 'host' && gameState.players[client.role]) {
        gameState.players[client.role] = gameState.players[client.role].filter(n => n !== client.name);
      }
      clients.delete(ws);
      broadcastState();
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
